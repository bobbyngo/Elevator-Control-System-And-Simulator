/**
 * This module contains the dependencies for the program.
 * @version 1.0, 02/04/23
 * @since 1.0, 02/04/23
 */
module elevatorControlSystemAndSimulator {
	requires java.sql;
	requires junit;
}