/**
 * 
 */
package main.java.elevator;

/**
 * @author Zakaria Ismail
 *
 */
public enum Door {
	OPEN,
	CLOSED
}
