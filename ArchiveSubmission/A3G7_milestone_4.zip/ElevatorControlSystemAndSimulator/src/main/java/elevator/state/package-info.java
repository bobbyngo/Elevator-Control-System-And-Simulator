/**
 * 
 */
/**
 * @author Zakaria Ismail
 *
 */
package main.java.elevator.state;