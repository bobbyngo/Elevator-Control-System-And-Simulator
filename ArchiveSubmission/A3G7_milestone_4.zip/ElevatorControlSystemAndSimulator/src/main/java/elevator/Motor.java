/**
 * 
 */
package main.java.elevator;

/**
 * @author Zakaria Ismail
 *
 */
public enum Motor {
	THROTTLE_UP,
	THROTTLE_DOWN,
	IDLE
}
